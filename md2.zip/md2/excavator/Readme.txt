//-----------------------------------------------------------------------------
//
// Copyright (C) 2004-2007  by W. Sitters
//
//  This model is free software, and has an double licence.
//  You can redistribute it and/or modify it under the terms of the 
//  GNU General Public License as published by the Free Software Foundation, 
//  either version 2 of the License, or any later version,
//  or you can redistribut it and/or modify it under the terms of
//  creative commons license CC-Attribution/by (http://creativecommons.org/licenses/by/3.0/).
// 
//
//  This model is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  You can choose your own licence ( GNU or CC-attribution/by ) for redistribute and/or modify,
//  but give credit to the orginal autor ( w. sitters ). 
//   
//
//  You should have received a copy of the GNU General Public License and CC_attribution licence
//  along with the model ; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 
//  02111-1307, USA or go to the website http://creativecommons.org/licenses/by/3.0/.
//
//
//  
//
//   DESCRIPTION: 3D model's' and textures
//
//-----------------------------------------------------------------------------
